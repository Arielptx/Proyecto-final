package sistema_pedidos.sistema.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import sistema_pedidos.sistema.models.Laboratorio;

@Repository
public interface LaboratorioRepository extends JpaRepository<Laboratorio, Integer> {
    // Aquí puedes agregar métodos personalizados si es necesario

}
