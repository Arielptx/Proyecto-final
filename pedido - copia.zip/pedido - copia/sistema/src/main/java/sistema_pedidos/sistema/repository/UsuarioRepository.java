package sistema_pedidos.sistema.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import sistema_pedidos.sistema.models.Usuario;

@Repository
public interface UsuarioRepository extends JpaRepository<Usuario, Integer> {

    Usuario findByCorreoAndCi(String correo, String ci); 

    Optional<Usuario> findByCorreo(String correo);
}

