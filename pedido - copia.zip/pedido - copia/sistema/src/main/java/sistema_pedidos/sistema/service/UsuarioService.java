package sistema_pedidos.sistema.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import sistema_pedidos.sistema.models.Usuario;
import sistema_pedidos.sistema.repository.UsuarioRepository;

@Service
public class UsuarioService {
    
    @Autowired
    private UsuarioRepository usuarioRepository;

    public List<Usuario> listaUsuarios(){
        return usuarioRepository.findAll();
    }

    public Usuario guardarUsuario(Usuario usuario){
        return usuarioRepository.save(usuario);
    }

    public Usuario obtenerUsuarioPorId(Integer id){
        return usuarioRepository.findById(id).orElse(null);
    }

    public void eliminarUsuario(Integer id){
        usuarioRepository.deleteById(id);
    }

    public Usuario editarUsuario(Usuario usuario){
        return usuarioRepository.save(usuario);
    }

}
