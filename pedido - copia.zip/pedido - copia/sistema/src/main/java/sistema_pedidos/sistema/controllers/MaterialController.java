package sistema_pedidos.sistema.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import sistema_pedidos.sistema.models.Materiales;
import sistema_pedidos.sistema.service.MaterialService;

@Controller
public class MaterialController {

    @Autowired
    private MaterialService materialService;

    /* funcion para mostrar datos en tablas html */
    @GetMapping("/materiales")
    public String listarMateriales(Model model) {
        model.addAttribute("materiales", materialService.listaMateriales());
        return "materiales";
    }
    
    /* llamar al registro para agregar materiales */
    @GetMapping("/materiales/nuevo")
    public String mostrarFormularioRegistro(Model model){
        Materiales material = new Materiales();
        model.addAttribute("material", material);
        return "registro_materiales";
    }    

    /* guardar nuevo material */
    @PostMapping("/materiales/guardar")
    public String guardarMaterial(@ModelAttribute("material") Materiales material) {
        materialService.guardarMaterial(material);
        return "redirect:/materiales";
    }

    /* eliminar material */
    @GetMapping("/materiales/eliminar/{id}")
    public String eliminarMaterial(@PathVariable("id") Integer id) {
        materialService.eliminarMaterial(id);
        return "redirect:/materiales";
    }

    /* editar datos de material */
    @GetMapping("/materiales/editar/{id}")
    public String editarMaterial(@PathVariable("id") Integer id, Model model) {
        Materiales material = materialService.obtenerMaterialPorId(id);
        if (material == null) {
            model.addAttribute("error", "Material no encontrado");
            return "error"; // Redirige a una página de error 
        }
        model.addAttribute("material", material);
        return "registro_materiales";
    }

    /* guardar cambios de material */
    @PostMapping("/materiales/actualizar")
    public String actualizarMaterial(@ModelAttribute("material") Materiales material) {
        materialService.editarMaterial(material);
        return "redirect:/materiales";
    }
}
