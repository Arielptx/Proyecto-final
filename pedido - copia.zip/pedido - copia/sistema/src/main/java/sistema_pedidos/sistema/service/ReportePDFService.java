package sistema_pedidos.sistema.service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.List;

import org.springframework.stereotype.Service;

import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

import sistema_pedidos.sistema.models.Devolucion;
import sistema_pedidos.sistema.models.Prestamo;

@Service
public class ReportePDFService {

    public ByteArrayInputStream generarReporte(List<Devolucion> devolucion){
        Document document = new Document();
        ByteArrayOutputStream out = new ByteArrayOutputStream();

        try {
            PdfWriter.getInstance(document, out);
            document.open();

            //titulo
            Font fontTitulo = new Font(Font.HELVETICA, 16, Font.BOLD);
            Paragraph titulo = new Paragraph("reporte de devoluciones", fontTitulo);
            titulo.setAlignment(Element.ALIGN_CENTER);
            document.add(titulo);
            document.add(Chunk.NEWLINE);

            //tabla
            PdfPTable tabla = new PdfPTable(6);
            tabla.setWidthPercentage(100);
            tabla.setWidths(new int[]{2, 2, 2, 2, 2, 3});

            Font cabecera = new Font(Font.HELVETICA, 12, Font.BOLD);

            tabla.addCell(new PdfPCell(new Phrase("Usuario", cabecera)));
            tabla.addCell(new PdfPCell(new Phrase("Material", cabecera)));
            tabla.addCell(new PdfPCell(new Phrase("Laboratorio", cabecera)));
            tabla.addCell(new PdfPCell(new Phrase("Fecha Prestamo", cabecera)));
            tabla.addCell(new PdfPCell(new Phrase("Fecha Devolucion", cabecera)));
            tabla.addCell(new PdfPCell(new Phrase("Observaciones", cabecera)));

            for (Devolucion d : devolucion){
                Prestamo p = d.getPrestamo();

                tabla.addCell(p.getUsuario().getNombres()+ " " + p.getUsuario().getApellido_paterno());
                tabla.addCell(p.getMaterial().getNombre());
                tabla.addCell(p.getLaboratorio().getNumero_laboratorio());
                tabla.addCell(p.getFechaPrestamo().toString());
                tabla.addCell(d.getFechaDevolucion().toString());
                tabla.addCell(d.getObservaciones());
            }

            document.add(tabla);
            document.close();


        } catch (DocumentException e) {
            e.printStackTrace();
        }
    
        return new ByteArrayInputStream(out.toByteArray());
    }
}

