package sistema_pedidos.sistema.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import sistema_pedidos.sistema.models.Usuario;
import sistema_pedidos.sistema.service.UsuarioService;

@Controller
public class UsuarioController {

    @Autowired
    private UsuarioService usuarioService;

    /* funcion para mostrar datos en tablas html */
    @GetMapping("/usuarios")
    public String listarUsuarios(Model model) {
        
        List<Usuario> lista = usuarioService.listaUsuarios();
        model.addAttribute("usuarios", lista);
        return "usuarios";
    }

    /* llamar al registro para agregar usuarios */
    @GetMapping("/usuarios/nuevo")
    public String mostrarFormularioRegistro(Model model) {
        Usuario usuario = new Usuario();
        model.addAttribute("usuario", usuario);
        return "registro_usuarios";
    }

    /* guardar nuevo usuario */
    @PostMapping("/usuarios/guardar")
    public String guardarUsuario(@ModelAttribute("usuario") Usuario usuario) {
        usuarioService.guardarUsuario(usuario);
        return "redirect:/usuarios";
    }

    /* eliminar usuario */
    @GetMapping("/usuarios/eliminar/{id}")
    public String eliminarUsuario(@PathVariable("id") Integer id) {
        usuarioService.eliminarUsuario(id);
        return "redirect:/usuarios";
    }

    /* editar datos de usuario */
    @GetMapping("/usuarios/editar/{id}")
    public String editarUsuario(@PathVariable("id") Integer id, Model model) {
        Usuario usuario = usuarioService.obtenerUsuarioPorId(id);
        if (usuario == null) {
            model.addAttribute("error", "Usuario no encontrado");
            return "error"; // Redirige a una página de error
        }
        model.addAttribute("usuario", usuario);
        return "registro_usuarios";
    }
    
    /* guardar cambios de usuario */
    @PostMapping("/usuarios/actualizar")
    public String actualizarUsuario(@ModelAttribute("usuario") Usuario usuario) {
        usuarioService.editarUsuario(usuario);
        return "redirect:/usuarios";
    }
}
