package sistema_pedidos.sistema.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import sistema_pedidos.sistema.models.Materiales;
import sistema_pedidos.sistema.repository.MaterialRepository;

@Service
public class MaterialService {
    
    @Autowired
    private MaterialRepository materialRepository;

    public List<Materiales> listaMateriales(){
        return materialRepository.findAll();
    }

    public Materiales guardarMaterial(Materiales material){
        return materialRepository.save(material);
    }

    public Materiales obtenerMaterialPorId(Integer id){
        return materialRepository.findById(id).orElse(null);
    }

    public void eliminarMaterial(Integer id){
        materialRepository.deleteById(id);
    }   

    public Materiales editarMaterial(Materiales material){
        return materialRepository.save(material);
    }
}
