package sistema_pedidos.sistema.controllers;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import sistema_pedidos.sistema.models.Devolucion;
import sistema_pedidos.sistema.models.Prestamo;
import sistema_pedidos.sistema.service.DevolucionService;
import sistema_pedidos.sistema.service.PrestamoService;

@Controller
public class DevolucionController {

    @Autowired
    private DevolucionService devolucionService;

    @Autowired
    private PrestamoService prestamoService;

    @GetMapping("/devoluciones/nuevo")
    public String registrarDevolucion(Model model) {
        model.addAttribute("prestamos", prestamoService.listaPrestamos());
        model.addAttribute("devolucion", new Devolucion());
        return "devolucion-registrar";  // Redirige a la vista del formulario de devolución
    }

    @PostMapping("/devoluciones/guardar")
    public String guardarDevolucion(@ModelAttribute Devolucion devolucion, 
                                    @RequestParam("id_prestamo") Integer idPrestamo,
                                    RedirectAttributes redirectAttributes) {
        Prestamo prestamo = prestamoService.obtenerPrestamoPorId(idPrestamo);
        if (prestamo == null){
            redirectAttributes.addFlashAttribute("error", "El préstamo no existe");
            return "redirect:/devoluciones/nuevo"; // Redirige a la vista del formulario de devolución
        }

        devolucion.setPrestamo(prestamo);
        devolucion.setFechaDevolucion(LocalDateTime.now());
        devolucionService.guardarDevolucion(devolucion);

        redirectAttributes.addFlashAttribute("success", "Devolución registrada exitosamente");

        return "redirect:/"; //redirige a la vista principal tras la creación de la devolución 
        }

}
