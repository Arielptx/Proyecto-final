package sistema_pedidos.sistema.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import sistema_pedidos.sistema.models.Laboratorio;
import sistema_pedidos.sistema.service.LaboratorioService;

@Controller
public class LaboratorioController {

    @Autowired
    private LaboratorioService laboratorioService;

    /* funcion para mostrar datos en tablas html */
    @GetMapping("/laboratorios")
    public String listarLaboratorios(Model model) {
        model.addAttribute("laboratorios", laboratorioService.listaLaboratorios());
        return "laboratorios";
    }

    /* llamar al registro para agregar laboratorio */
    @GetMapping("/laboratorios/nuevo")
    public String mostrarFormularioRegistro(Model model){
        Laboratorio laboratorio = new Laboratorio();
        model.addAttribute("laboratorio", laboratorio);
        return "registro_laboratorios";
    }

    /* guardar nuevo laboratorio */
    @PostMapping("/laboratorios/guardar")
    public String guardarLaboratorio(@ModelAttribute("laboratorio") Laboratorio laboratorio){
        laboratorioService.guardarLaboratorio(laboratorio);
        return "redirect:/laboratorios";
    }

    /* eliminarl laboratorio */
    @GetMapping("/laboratorios/eliminar/{id}")
    public String eliminarLaboratorio(@PathVariable("id") Integer id){
        laboratorioService.eliminarLaboratorio(id);
        return "redirect:/laboratorios";
    }

    /* editar datos de laboratorio */
    @GetMapping("/laboratorios/editar/{id}")
    public String editarLaboratorio(@PathVariable("id") Integer id, Model model) {
        Laboratorio laboratorio = laboratorioService.obtenerLaboratorioPorId(id);
        if (laboratorio == null){
            model.addAttribute("error", "Laboratorio no encontrado");
            return "error"; // Redirige a una página de error 
        }
        model.addAttribute("laboratorio", laboratorio);
        return "registro_laboratorios";
    }

    /* guardar cambios de laboratorio */
    @PostMapping("/laboratorios/actualizar")
    public String actualizarLaboratorio(@ModelAttribute("laboratorio") Laboratorio laboratorio) {
        laboratorioService.editarLaboratorio(laboratorio);
        return "redirect:/laboratorios";
    }
}
