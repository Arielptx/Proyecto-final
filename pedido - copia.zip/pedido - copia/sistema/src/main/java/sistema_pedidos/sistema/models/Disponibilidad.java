package sistema_pedidos.sistema.models;

public enum Disponibilidad {
    Disponible, No_disponible
}