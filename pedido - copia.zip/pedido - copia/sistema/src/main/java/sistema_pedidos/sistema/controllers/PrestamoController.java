package sistema_pedidos.sistema.controllers;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jakarta.servlet.http.HttpServletRequest;
import sistema_pedidos.sistema.models.Laboratorio;
import sistema_pedidos.sistema.models.Materiales;
import sistema_pedidos.sistema.models.Prestamo;
import sistema_pedidos.sistema.models.Usuario;
import sistema_pedidos.sistema.repository.LaboratorioRepository;
import sistema_pedidos.sistema.repository.MaterialRepository;
import sistema_pedidos.sistema.repository.UsuarioRepository;
import sistema_pedidos.sistema.service.PrestamoService;


@Controller
public class PrestamoController {

    @Autowired
    private MaterialRepository materialRepository;

    @Autowired
    private LaboratorioRepository laboratorioRepository;

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private PrestamoService prestamoService;

    @GetMapping("/prestamos/nuevo")
    public String registrarPrestamo(Model model) {
        model.addAttribute("materiales", materialRepository.findAll());
        model.addAttribute("laboratorios", laboratorioRepository.findAll());
        return "prestamo-material-lab";  // Redirige a la vista del formulario de préstamo
    }

    @PostMapping("prestamos/guardar")
    public String guardarPrestamo(HttpServletRequest request, RedirectAttributes redirectAttributes) {
        String ci = request.getParameter("ci");
        String correo = request.getParameter("correo");

        Usuario usuario = usuarioRepository.findByCorreoAndCi(correo, ci);
        if (usuario == null){
            redirectAttributes.addFlashAttribute("error", "El usuario no existe, registrelo primero");
            return "redirect:/prestamos/nuevo"; // Redirige a la vista del formulario de préstamo
        }

        int idMaterial = Integer.parseInt(request.getParameter("id_material"));
        int idLaboratorio = Integer.parseInt(request.getParameter("id_laboratorio"));


        Materiales material = materialRepository.findById(idMaterial).orElse(null);
        Laboratorio laboratorio = laboratorioRepository.findById(idLaboratorio).orElse(null);

        Prestamo prestamo = new Prestamo();
        prestamo.setUsuario(usuario);
        prestamo.setMaterial(material);
        prestamo.setLaboratorio(laboratorio);
        prestamo.setEstado("Pendiente");
        prestamo.setFechaPrestamo(LocalDateTime.now());

        prestamoService.guardarPrestamo(prestamo);

        redirectAttributes.addFlashAttribute("success", "Préstamo registrado exitosamente");
        return "redirect:/"; // Redirige a la vista del formulario de préstamo
    } 
}
