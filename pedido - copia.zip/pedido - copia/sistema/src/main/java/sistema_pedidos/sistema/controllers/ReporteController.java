package sistema_pedidos.sistema.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import sistema_pedidos.sistema.models.Devolucion;
import sistema_pedidos.sistema.repository.DevolucionRepository;
import sistema_pedidos.sistema.service.ReportePDFService;

import java.io.ByteArrayInputStream;
import java.util.List;


@RestController
@RequestMapping("/reporte")
public class ReporteController {

    @Autowired
    private ReportePDFService reportePDFService;

    @Autowired
    private DevolucionRepository devolucionRepository;

    @GetMapping("/pdf")
    public ResponseEntity<InputStreamResource> generarReporte(){
        List<Devolucion> devoluciones = devolucionRepository.findAll();

        ByteArrayInputStream bis = reportePDFService.generarReporte(devoluciones);

        HttpHeaders headers = new HttpHeaders();
        headers.add("Content.Disposition", "inline; filename=reporte.pdf");

        return ResponseEntity
            .ok()
            .headers(headers)
            .contentType(MediaType.APPLICATION_PDF)
            .body(new InputStreamResource(bis));
    }
}
