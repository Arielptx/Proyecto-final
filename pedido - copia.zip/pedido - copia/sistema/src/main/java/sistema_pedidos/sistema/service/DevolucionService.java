package sistema_pedidos.sistema.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import sistema_pedidos.sistema.models.Devolucion;
import sistema_pedidos.sistema.repository.DevolucionRepository;

@Service
public class DevolucionService {

    @Autowired
    private DevolucionRepository devolucionRepository;
    
    public List<Devolucion> listaDevoluciones() {
        return devolucionRepository.findAll();
    }

    public Devolucion obtenerDevolucionPorId(Integer id) {
        return devolucionRepository.findById(id).orElse(null);
    }

    public void guardarDevolucion(Devolucion devolucion) {
        devolucionRepository.save(devolucion);
    }
}
