package sistema_pedidos.sistema.models;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "devolucion")
public class Devolucion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id_devolucion;

    @Column(name = "fecha_devolucion", columnDefinition = "TIMESTAMP")
    private LocalDateTime fechaDevolucion;

    private String observaciones;

    @ManyToOne
    @JoinColumn(name = "id_prestamo", nullable = false)
    private Prestamo prestamo;

    public Devolucion() {
    }

    public Devolucion(int id_devolucion, LocalDateTime fechaDevolucion, String observaciones, Prestamo prestamo) {
        this.id_devolucion = id_devolucion;
        this.fechaDevolucion = fechaDevolucion;
        this.observaciones = observaciones;
        this.prestamo = prestamo;
    }

    public Devolucion(LocalDateTime fechaDevolucion, String observaciones, Prestamo prestamo) {
        this.fechaDevolucion = fechaDevolucion;
        this.observaciones = observaciones;
        this.prestamo = prestamo;
    }

    public int getId_devolucion() {
        return id_devolucion;
    }

    public void setId_devolucion(int id_devolucion) {
        this.id_devolucion = id_devolucion;
    }

    public LocalDateTime getFechaDevolucion() {
        return fechaDevolucion;
    }

    public void setFechaDevolucion(LocalDateTime fechaDevolucion) {
        this.fechaDevolucion = fechaDevolucion;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    public Prestamo getPrestamo() {
        return prestamo;
    }

    public void setPrestamo(Prestamo prestamo) {
        this.prestamo = prestamo;
    }

}
