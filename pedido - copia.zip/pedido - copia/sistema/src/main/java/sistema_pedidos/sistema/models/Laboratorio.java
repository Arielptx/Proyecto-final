package sistema_pedidos.sistema.models;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "laboratorio")
public class Laboratorio {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id_laboratorio;

    private String numero_laboratorio;
    private int cantidad_equipos;

    @Enumerated(EnumType.STRING)
    private Disponibilidad disponibilidad;

    public Laboratorio() {
    }

    public Laboratorio(int cantidad_equipos, Disponibilidad disponibilidad, int id_laboratorio, String numero_laboratorio) {
        this.cantidad_equipos = cantidad_equipos;
        this.disponibilidad = disponibilidad;
        this.id_laboratorio = id_laboratorio;
        this.numero_laboratorio = numero_laboratorio;
    }

    public Laboratorio(String numero_laboratorio, int cantidad_equipos, Disponibilidad disponibilidad) {
        this.numero_laboratorio = numero_laboratorio;
        this.cantidad_equipos = cantidad_equipos;
        this.disponibilidad = disponibilidad;
    }

    public int getId_laboratorio() {
        return id_laboratorio;
    }

    public void setId_laboratorio(int id_laboratorio) {
        this.id_laboratorio = id_laboratorio;
    }

    public String getNumero_laboratorio() {
        return numero_laboratorio;
    }

    public void setNumero_laboratorio(String numero_laboratorio) {
        this.numero_laboratorio = numero_laboratorio;
    }

    public int getCantidad_equipos() {
        return cantidad_equipos;
    }

    public void setCantidad_equipos(int cantidad_equipos) {
        this.cantidad_equipos = cantidad_equipos;
    }

    public Disponibilidad getDisponibilidad() {
        return disponibilidad;
    }

    public void setDisponibilidad(Disponibilidad disponibilidad) {
        this.disponibilidad = disponibilidad;
    }
}
