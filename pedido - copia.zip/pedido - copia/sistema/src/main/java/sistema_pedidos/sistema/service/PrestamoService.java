package sistema_pedidos.sistema.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import sistema_pedidos.sistema.models.Prestamo;
import sistema_pedidos.sistema.repository.PrestamoRepository;

@Service
public class PrestamoService {

    @Autowired
    private PrestamoRepository prestamoRepository;

    public List<Prestamo> listaPrestamos() {
        return prestamoRepository.findAll();
    }

    public Prestamo obtenerPrestamoPorId(Integer id) {
        return prestamoRepository.findById(id).orElse(null);
    }

    public void guardarPrestamo(Prestamo prestamo) {
        prestamoRepository.save(prestamo);
    }
}
