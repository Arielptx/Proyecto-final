package sistema_pedidos.sistema.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import sistema_pedidos.sistema.models.Laboratorio;
import sistema_pedidos.sistema.repository.LaboratorioRepository;

@Service
public class LaboratorioService {

    @Autowired
    private LaboratorioRepository laboratorioRepository;

    public List<Laboratorio> listaLaboratorios(){
        return laboratorioRepository.findAll();
    }

    public Laboratorio guardarLaboratorio(Laboratorio laboratorio){
        return laboratorioRepository.save(laboratorio);
    }

    public Laboratorio obtenerLaboratorioPorId(Integer id){
        return laboratorioRepository.findById(id).orElse(null);
    }   

    public void eliminarLaboratorio(Integer id){
        laboratorioRepository.deleteById(id);
    }

    public Laboratorio editarLaboratorio(Laboratorio laboratorio){
        return laboratorioRepository.save(laboratorio);
    }

}
