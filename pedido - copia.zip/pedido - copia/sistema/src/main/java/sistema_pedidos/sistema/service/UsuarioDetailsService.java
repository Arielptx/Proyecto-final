package sistema_pedidos.sistema.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import sistema_pedidos.sistema.models.Usuario;
import sistema_pedidos.sistema.repository.UsuarioRepository;

@Service
public class UsuarioDetailsService implements UserDetailsService {
    
    @Autowired
    private UsuarioRepository usuarioRepository;

    @Override
    public UserDetails loadUserByUsername(String correo) throws UsernameNotFoundException {
        Usuario usuario = usuarioRepository.findByCorreo(correo)
            .orElseThrow(() -> new UsernameNotFoundException("usuario no encontrado"));

        System.out.println("Contraseña almacenada: " + usuario.getPassword());

        
        return User.builder()
            .username(usuario.getCorreo())
            .password(usuario.getPassword())
            .roles(usuario.getRol())
            .build();
    } 
}
