package sistema_pedidos.sistema;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaApplicationTests {

	@Test
	void contextLoads() {
	}

}
